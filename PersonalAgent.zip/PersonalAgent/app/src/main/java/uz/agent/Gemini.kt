package uz.agent

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Msg(val user: Boolean, val text: String)

object Gemini {
    private const val JEV_PROMPT =
        "Javobni 1-3 qisqa jumlada ber. Faqat aniq natija: qaror, raqam yoki xulosa. " +
            "Salomlashish, izoh va ortiqcha so'z yo'q. Foydalanuvchi tilida yoz."

    private const val AGENT_PROMPT =
        "Sen universal shaxsiy AI agentsan. Foydalanuvchi tilida aniq, tez va foydali javob ber. " +
            "Kerak bo'lmasa uzun yozma."

    suspend fun stream(
        key: String,
        model: String,
        jev: Boolean,
        history: List<Msg>,
        onChunk: suspend (String) -> Unit
    ) {
        withContext(Dispatchers.IO) {
            val contents = JSONArray()
            history.forEach { m ->
                contents.put(
                    JSONObject()
                        .put("role", if (m.user) "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", m.text)))
                )
            }

            val gen = JSONObject().put("maxOutputTokens", if (jev) 256 else 1024)
            // Gemini 2.5 Flash: thinking off = faster replies
            if (model.startsWith("gemini-2.5-flash")) {
                gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
            }

            val systemText = if (jev) JEV_PROMPT else AGENT_PROMPT
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemText))))
                .put("contents", contents)
                .put("generationConfig", gen)
            // Normal mode can use Google Search for up-to-date answers
            if (!jev) {
                body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            }

            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse&key=$key")
            val conn = url.openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.connectTimeout = 15_000
                conn.readTimeout = 60_000
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

                if (conn.responseCode !in 200..299) {
                    val err = conn.errorStream?.bufferedReader()?.readText().orEmpty()
                    val msg = runCatching { JSONObject(err).getJSONObject("error").getString("message") }
                        .getOrDefault("HTTP ${conn.responseCode}")
                    throw IllegalStateException(msg)
                }

                conn.inputStream.bufferedReader().use { reader ->
                    while (true) {
                        val line = reader.readLine() ?: break
                        if (!line.startsWith("data: ")) continue
                        val text = JSONObject(line.substring(6))
                            .optJSONArray("candidates")?.optJSONObject(0)
                            ?.optJSONObject("content")?.optJSONArray("parts")
                            ?.optJSONObject(0)?.optString("text").orEmpty()
                        if (text.isNotEmpty()) onChunk(text)
                    }
                }
            } finally {
                conn.disconnect()
            }
        }
    }
}
