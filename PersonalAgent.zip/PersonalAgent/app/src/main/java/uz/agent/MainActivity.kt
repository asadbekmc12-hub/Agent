package uz.agent

import android.app.Application
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                ChatScreen()
            }
        }
    }
}

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("agent", Context.MODE_PRIVATE)
    val messages = mutableStateListOf<Msg>()

    var jev by mutableStateOf(prefs.getBoolean("jev", false))
        private set

    var busy by mutableStateOf(false)
        private set

    private fun reply(text: String) {
        messages.add(Msg(false, text))
    }

    private fun setJev(on: Boolean) {
        jev = on
        prefs.edit().putBoolean("jev", on).apply()
        reply(if (on) "Jev AI yoqildi. Qisqa va aniq rejim." else "Jev AI o'chirildi. Oddiy rejim.")
    }

    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty() || busy) return

        // Local commands are handled here and never sent to Gemini
        val low = text.lowercase().replace('ʻ', '\'').replace('’', '\'').replace('‘', '\'')
        val words = low.split(Regex("[\\s,.!?]+"))

        when {
            low == "/tozala" -> { messages.clear(); return }
            low.startsWith("/kalit ") -> {
                prefs.edit().putString("key", text.substringAfter(" ").trim()).apply()
                reply("API kalit saqlandi.")
                return
            }
            low.startsWith("/model ") -> {
                val name = text.substringAfter(" ").trim()
                prefs.edit().putString("model", name).apply()
                reply("Model saqlandi: $name")
                return
            }
            "jev" in words && ("yoq" in words || "on" in words) -> { setJev(true); return }
            "jev" in words && ("o'chir" in words || "ochir" in words || "off" in words) -> { setJev(false); return }
        }

        val key = prefs.getString("key", "").orEmpty()
        if (key.isEmpty()) {
            reply("Boshlash uchun Gemini API kalitni kiriting:\n/kalit <kalit>")
            return
        }

        messages.add(Msg(true, text))
        val history = messages.filter { it.text.isNotBlank() }.takeLast(12).dropWhile { !it.user }
        messages.add(Msg(false, ""))
        val idx = messages.lastIndex
        val model = prefs.getString("model", "gemini-2.5-flash").orEmpty()

        busy = true
        viewModelScope.launch {
            try {
                Gemini.stream(key, model, jev, history) { chunk ->
                    withContext(Dispatchers.Main) {
                        messages[idx] = messages[idx].copy(text = messages[idx].text + chunk)
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    messages[idx] = Msg(false, "Xato: ${e.message ?: "noma'lum xato"}")
                }
            } finally {
                busy = false
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel = viewModel()) {
    var input by remember { mutableStateOf("") }
    val list = rememberLazyListState()

    LaunchedEffect(vm.messages.size, vm.messages.lastOrNull()?.text) {
        if (vm.messages.isNotEmpty()) list.scrollToItem(vm.messages.lastIndex)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (vm.jev) "Jev AI" else "AI Agent", fontWeight = FontWeight.SemiBold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = if (vm.jev) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surface
                ),
                actions = { TextButton(onClick = { vm.send("/tozala") }) { Text("Tozala") } }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().imePadding()) {
            LazyColumn(
                state = list,
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (vm.messages.isEmpty()) {
                    item {
                        Text(
                            "Salom. Boshlash uchun: /kalit <Gemini API kalit>\n" +
                                "Jev rejimi: \"jev yoq\" yoki \"jev o'chir\"",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 12.dp)
                        )
                    }
                }
                items(vm.messages) { Bubble(it) }
            }

            Row(
                Modifier.fillMaxWidth().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Xabar yozing") },
                    maxLines = 4
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = { vm.send(input); input = "" },
                    enabled = input.isNotBlank() && !vm.busy
                ) { Text("Yubor") }
            }
        }
    }
}

@Composable
fun Bubble(m: Msg) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (m.user) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (m.user) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Text(
                m.text.ifEmpty { "..." },
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }
    }
}
